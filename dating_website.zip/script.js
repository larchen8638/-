const form = document.getElementById('userForm');
const profileList = document.getElementById('profileList');

form.addEventListener('submit', function(e) {
    e.preventDefault();
    const data = new FormData(form);
    const reader = new FileReader();
    reader.onload = function() {
        const profile = {
            name: data.get('name'),
            age: data.get('age'),
            gender: data.get('gender'),
            hobbies: data.get('hobbies'),
            description: data.get('description'),
            avatar: reader.result
        };
        const div = document.createElement('div');
        div.className = 'profile-card';
        div.innerHTML = `<img src='${profile.avatar || "https://via.placeholder.com/80"}' alt='头像'>
                         <div><strong>${profile.name}</strong> (${profile.age}岁, ${profile.gender})<br>
                         爱好: ${profile.hobbies}<br>
                         自我评价: ${profile.description}</div>`;
        profileList.appendChild(div);
        form.reset();
    };
    const file = data.get('avatar');
    if(file && file.size > 0){ reader.readAsDataURL(file); }
    else{ reader.onload(); }
});
